cd `dirname $0`
mvn -e -f pom-manager.xml exec:java
